export class User {
    id: number = 0;
    consumer_name: string = '';
    mobile_no: string = '';
    email: string = '';
    loggedIn: boolean = false;
    gender: string = '';
    dob: string = '';
    address: string = '';
    city: string = '';
    state: string = '';
    aadhaar_no: string = '';
    pancard: string = '';
    pincode: string = '';
    image: string = '';
};