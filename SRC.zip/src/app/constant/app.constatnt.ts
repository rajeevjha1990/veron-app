export const INT_API_URL = 'http://localhost/veron-api/public/';
export const EXT_API_URL = 'https://veronmoney.com/webservice/public/';
export const API_PATH = 'api/';
export const USER_API_PATH = 'auth/';
export const CONSUMER_API_PATH = 'consumer/';


